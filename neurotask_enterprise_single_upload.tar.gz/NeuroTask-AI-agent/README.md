
# NeuroTask Enterprise SaaS

## Run locally

docker-compose up --build

Frontend:
http://localhost:3000

Backend:
http://localhost:8000

Health:
http://localhost:8000/health
