
import React from "react"

export default function Dashboard(){
 return (
   <div style={{padding:20}}>
     <h1>NeuroTask Enterprise SaaS</h1>
     <p>System running successfully</p>
   </div>
 )
}
